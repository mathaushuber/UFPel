public class Nodo {
	
    private int idade;

    public Nodo(int idade) {
        this.idade = idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getIdade() {
        return idade;
    }
}
